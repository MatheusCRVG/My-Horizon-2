#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    my_horizon_native::run();
}
